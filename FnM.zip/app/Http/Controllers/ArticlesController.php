<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
//use App\Models\Article;
use App\Article;
use Illuminate\Support\Facades\Session;

class ArticlesController extends Controller
{
    //
    /**
         * Display articles.
         *
         * @return \Illuminate\Http\Response
         */
        public function articles()
        {
            $articles = Article::orderBy('created_at', 'desc')->paginate(10);
            return view('articles')->with('articles',$articles);
        }

        /**
         * Remove the specified resource from storage.
         *
         * @param  \App\Model\Category  $category
         * @return \Illuminate\Http\Response
         */
        public function destroyArticle(Article $article)
        {
            unlink('uploads/articles/'.$article->image);
            $article->delete();
            Session::flash('success', 'Your article had been deleted successfully!');
            return redirect()->back();
        }

        /**
         * Remove the specified resource from storage.
         *
         * @param  \App\Model\Category  $category
         * @return \Illuminate\Http\Response
         */
        public function addArticleView()
        {
            return view('add_article');
        }

        /**
         * Store a newly created resource in storage.
         *
         * @param  \Illuminate\Http\Request  $request
         * @return \Illuminate\Http\Response
         */
        public function addArticle(Request $request)
        {
            if (!empty($request->image)) {
                $new_name = time() . $request->file('image')->getClientOriginalName();
                $request->image->move('uploads/articles/', $new_name);
                $recipe = Article::create([
                'title' => $request->title,
                'image' => $new_name,
                'text' => $request->text,
                ]);
                Session::flash('success', 'Your article had been added successfully!');
                return redirect()->back();
            }
            Session::flash('error', 'Add a valid image!');
            return redirect()->back();
        }

        /**
         * Remove the specified resource from storage.
         *
         * @param  \App\Model\Category  $category
         * @return \Illuminate\Http\Response
         */
        public function editArticleView(Article $article)
        {
            return view('edit_article')->with(['article'=>$article]);
        }

        /**
         * Update the specified resource in storage.
         *
         * @param  \Illuminate\Http\Request  $request
         * @param  \App\Model\Category  $category
         * @return \Illuminate\Http\Response
         */
        public function updateArticle(Request $request, Article $article)
        {
            if (!empty($request->image)) {
                unlink('uploads/articles/'.$article->image);
                $new_name = time() . $request->file('image')->getClientOriginalName();
                $request->image->move('uploads/articles/', $new_name);
                $article->image = $new_name;
            }

            $article->title = $request->title;
            $article->text = $request->text;
            $article->save();
            Session::flash('success', 'Your Article had been updated successfully!');
            return redirect()->back();
        }
}
