<?php

namespace App\Http\Controllers;

use App\Article;
use App\Http\Resources\Articles\ArticlesCollection;
use Illuminate\Http\Request;

class ApiArticlesController extends Controller
{
	public function mainArticles() {
    	$articles = Article::orderBy('id', 'desc')->take(10)->get();
        return ArticlesCollection::collection($articles);
    }

    public function articles() {
    	$articles = Article::all();
        return ArticlesCollection::collection($articles);
    }
}
