<?php

namespace App\Http\Resources\Articles;

use Illuminate\Http\Resources\Json\Resource;

class ArticlesCollection extends Resource
{
    /**
     * Transform the resource collection into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return
        [
        'id'=>$this->id,
        'title'=>$this->title,
        'image'=>$this->image,
        'text'=>$this->text,
        'text_small'=>mb_strimwidth($this->text, 0, 95, ' ...'),
        'date'=>$this->created_at->format('jS F Y')
    ];
    }
}
