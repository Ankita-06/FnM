<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Route::prefix('admin')->middleware(['auth', 'isAdmin'])->group(function(){

    Route::get('/dashboard', [App\Http\Controllers\Admin\DashboardController::class, 'index'])->name('dashboard');

    // Articles Management
        //Route::get('/articles', 'ArticlesController@articles')->name('articles');
        //Route::get('/articles/{article}/delete', 'ArticlesController@destroyArticle')->name('article.delete');
        //Route::get('/articles/add/new', 'ArticlesController@addArticleView')->name('article.add.view');
        //Route::post('/articles/admin/add', 'ArticlesController@addArticle')->name('article.add.admin');
        //Route::get('/articles/{article}/edit', 'ArticlesController@editArticleView')->name('article.edit');
        //Route::post('/articles/{article}/update', 'ArticlesController@updateArticle')->name('article.update');

        Route::get('/articles', [App\Http\Controllers\ArticlesController::class, 'articles'])->name('articles');
        Route::get('/articles/add/new', [App\Http\Controllers\ArticlesController::class, 'addArticleView'])->name('article.add.view');
        Route::post('/articles/admin/add', [App\Http\Controllers\ArticlesController::class, 'addArticle'])->name('article.add.admin');
        Route::get('/articles/{article}/edit', [App\Http\Controllers\ArticlesController::class, 'editArticleView'])->name('article.edit');
        Route::post('/articles/{article}/update', [App\Http\Controllers\ArticlesController::class, 'updateArticle'])->name('article.update');
        Route::get('/articles/{article}/delete', [App\Http\Controllers\ArticlesController::class, 'destroyArticle'])->name('article.delete');
});
