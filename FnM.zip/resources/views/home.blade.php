@include('partials.header')

@include('partials.sidebar')

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
    <div id="content">

        @include('partials.navbar')

        @include('partials.content')

    </div>
    <!-- End of Main Content -->

@include('partials.footer')
