<?php $__env->startSection('title'); ?>
Articles
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
<div class="row">
    <!-- Earnings (Monthly) Card Example -->
    <div class="col-lg-12">
      <div class="card border-left-dark shadow h-100 py-2">
        <div class="card-body col-lg-12">
          <?php if(Session::has('success')): ?>
          <div class="row">
            <div class="col-lg-8 offset-lg-2 col-md-12">
              <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(Session::get('success')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
              </div>
            </div>
          </div>
          <br>
          <?php endif; ?>
          <?php if(Session::has('error')): ?>
          <div class="row">
            <div class="col-lg-8 offset-lg-2 col-md-12">
              <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo e(Session::get('error')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
              </div>
            </div>
          </div>
          <br>
          <?php endif; ?>
          <div class="row">
            <div class="col-lg-6 col-md-12">
              <a class="btn-success btn-block btn" href="<?php echo e(route('article.add.view')); ?>"><i class="fas fa-plus"></i> Add New Article</a>
            </div>
            <br>
            <div class="col-lg-6 col-md-12">
              <a class="btn-dark btn-block btn" href="<?php echo e(route('dashboard')); ?>"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
            </div>
          </div>
          <br>
          <div class="row no-gutters align-items-center table-responsive">
            <table class="table table-bordered text-center">
              <thead>
                <tr>
                  <th scope="col">Title</th>
                  <th scope="col">Image</th>
                  <th scope="col">Actions</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td class="align-middle"><?php echo e($article->title); ?></td>
                  <td class="align-middle"><img src="<?php echo e(asset('uploads/articles/'.$article->image)); ?>" height="120px"></td>
                  <td class="align-middle">
                    <a class="btn btn-sm btn-primary" href="<?php echo e(route('article.edit', ['article'=>$article->id])); ?>"><i class="fas fa-edit"></i> Edit Article</a>
                    <a class="btn btn-sm btn-danger" href="<?php echo e(route('article.delete', ['article'=>$article->id])); ?>"><i class="fas fa-minus-circle"></i> Delete Article</a>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
            <div style="">
              <?php echo e($articles->links()); ?>

            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FnM-DB\Database_Recipe\resources\views/articles.blade.php ENDPATH**/ ?>