<?php $__env->startSection('title'); ?>
Dashboard
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <!-- Chefs Card -->
        <div class="col-lg-4 col-md-6 col-sm-12 mb-25" style="margin-top: 20px;">
            <div class="card border-left-dark shadow h-100 py-2">
                <div class="card-body">
                    <div class="panel-card row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="font-weight-bold text-smaller text-dark text-uppercase mb-1 cards-title">Diets</div>
                            <div class="h5 mb-0 text-gray-800">
                                <a href="" class="edit-section badge badge-dark">Manage</a>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-users fa-3x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Categories Card -->
        <div class="col-lg-4 col-md-6 col-sm-12 mb-25" style="margin-top: 20px;">
            <div class="card border-left-dark shadow h-100 py-2">
                <div class="card-body">
                    <div class="panel-card row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="font-weight-bold text-smaller text-dark text-uppercase mb-1 cards-title">Categories</div>
                            <div class="h5 mb-0 text-gray-800">
                                <a href="" class="edit-section badge badge-dark">Manage</a>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-bars fa-3x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Meals Card -->
        <div class="col-lg-4 col-md-6 col-sm-12 mb-25" style="margin-top: 20px;">
            <div class="card border-left-dark shadow h-100 py-2">
                <div class="card-body">
                    <div class="panel-card row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="font-weight-bold text-smaller text-dark text-uppercase mb-1 cards-title">Meals</div>
                            <div class="h5 mb-0 text-gray-800">
                                <a href="" class="edit-section badge badge-dark">Manage</a>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-clock fa-3x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Cuisines Card -->
        <div class="col-lg-4 col-md-6 col-sm-12 mb-25" style="margin-top: 40px;">
            <div class="card border-left-dark shadow h-100 py-2">
                <div class="card-body">
                    <div class="panel-card row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="font-weight-bold text-smaller text-dark text-uppercase mb-1 cards-title">Cuisines</div>
                            <div class="h5 mb-0 text-gray-800">
                                <a href="" class="edit-section badge badge-dark">Manage</a>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-flag-checkered fa-3x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Recipes Card -->
        <div class="col-lg-4 col-md-6 col-sm-12 mb-25" style="margin-top: 40px;">
            <div class="card border-left-dark shadow h-100 py-2">
                <div class="card-body">
                    <div class="panel-card row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="font-weight-bold text-smaller text-dark text-uppercase mb-1 cards-title">All Recipes</div>
                            <div class="h5 mb-0 text-gray-800">
                                <a href="" class="edit-section badge badge-dark">Manage</a>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-utensils fa-3x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Pending Review Card -->
        <div class="col-lg-4 col-md-6 col-sm-12 mb-25" style="margin-top: 40px;">
            <div class="card border-left-dark shadow h-100 py-2">
                <div class="card-body">
                    <div class="panel-card row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="font-weight-bold text-smaller text-dark text-uppercase mb-1 cards-title">Pending Review</div>
                            <div class="h5 mb-0 text-gray-800">
                                <a href="" class="edit-section badge badge-dark">Manage</a>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-hourglass-half fa-3x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Articles Card -->
                <div class="col-lg-4 col-md-6 col-sm-12 mb-25" style="margin-top: 40px;">
                    <div class="card border-left-dark shadow h-100 py-2">
                        <div class="card-body">
                            <div class="panel-card row no-gutters align-items-center">
                                <div class="col mr-2">
                                    <div class="font-weight-bold text-smaller text-dark text-uppercase mb-1 cards-title">Articles</div>
                                    <div class="h5 mb-0 text-gray-800">
                                        <a href="<?php echo e(route('articles')); ?>" class="edit-section badge badge-dark">Manage</a>
                                    </div>
                                </div>
                                <div class="col-auto">
                                    <i class="fa fa-file-text fa-3x text-gray-300"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        <!-- Admins Card -->
        <div class="col-lg-4 col-md-6 col-sm-12 mb-25" style="margin-top: 40px;">
            <div class="card border-left-dark shadow h-100 py-2">
                <div class="card-body">
                    <div class="panel-card row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="font-weight-bold text-smaller text-dark text-uppercase mb-1 cards-title">Admins</div>
                            <div class="h5 mb-0 text-gray-800">
                                <a href="" class="edit-section badge badge-dark">Manage</a>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-user-lock fa-3x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Ads Card -->
        <div class="col-lg-4 col-md-6 col-sm-12 mb-25" style="margin-top: 40px;">
            <div class="card border-left-dark shadow h-100 py-2">
                <div class="card-body">
                    <div class="panel-card row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="font-weight-bold text-smaller text-dark text-uppercase mb-1 cards-title">Ads</div>
                            <div class="h5 mb-0 text-gray-800">
                                <a href="" class="edit-section badge badge-dark">Manage</a>
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fab fa-buysellads fa-3x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FnM-DB\Database_Recipe\resources\views/dashboard.blade.php ENDPATH**/ ?>